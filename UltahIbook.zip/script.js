function myFunction() {
  document.getElementById("gambar").src = "./image/birthday-3148707_1280.png";
  document.getElementById("text").innerHTML = "hallo ibuuukk, giman akabarnya     sehat kan ya buuk?... sehat selalu yaaa iki program percobaan e ilham gawe     website eheh, egen kurang maximal tapi ilham bakalan tetep belajar, oh iya     selamat ulang tahun ya buk  yang ke 43 sehat selalu buat ibuk yaaa";
  document
}

function myFunction2() {
  document.getElementById
}



  
   
